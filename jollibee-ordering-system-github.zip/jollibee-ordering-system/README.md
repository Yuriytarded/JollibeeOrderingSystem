# Jollibee Ordering System

A simple command-line Jollibee ordering system written in Python. Customers can browse menu categories, place orders, choose dine-in or takeout, and select a payment method. Administrators can review orders and update their status.

## Features

- Food menu organized by category
- Item quantities, subtotals, and order totals
- Dine-in and takeout order types
- Cash and simulated online payment selection (GCash or GoTyme)
- Random four-digit order numbers
- Estimated preparation time
- Order receipt and pickup/dine-in reminder
- Admin login, order listing, order details, and status updates

## Requirements

- Python 3.8 or newer
- No third-party packages required

## Run the program

1. Clone or download this repository.
2. Open a terminal in the project folder.
3. Run:

   ```bash
   python main.py
   ```

## Admin login

The current demo password is `1234`.

**Important:** This password is hard-coded for demonstration purposes. Change it before sharing or deploying the project. Orders are stored in memory, so they are cleared when the program exits.

## Project structure

```text
jollibee-ordering-system/
├── main.py
├── README.md
└── .gitignore
```

## Notes

This is an educational command-line project. Online payment options are simulated; the program does not process or verify real payments.
